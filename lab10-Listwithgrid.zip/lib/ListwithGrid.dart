
import 'package:flutter/material.dart';

class Listproject extends StatefulWidget {
  Listproject({super.key});

  @override
  State<Listproject> createState() => _ListprojectState();
}

class _ListprojectState extends State<Listproject> {
  bool isGridSelected = true;
  List student = ["Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit"];

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Center(child: Text("List Scrolling Widgets",style: TextStyle(fontSize: 30),)),
        backgroundColor: Colors.white24,foregroundColor: Colors.black,
        actions: [
          Container(
            color: isGridSelected ? Colors.transparent : Colors.blueGrey,
            child: IconButton(
                icon: Icon(Icons.list),iconSize: 30, onPressed: () {
                   setState(() {
                     isGridSelected = false;
                   });
              },
            )
          ),
          Container(
            color: isGridSelected ? Colors.blueGrey : Colors.transparent,
            child: IconButton(
                icon: Icon(Icons.grid_3x3),iconSize: 30, onPressed: () {
                   setState(() {
                     isGridSelected = true;
                   });
              },
            )
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: isGridSelected ? GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3), itemBuilder: (context, index) {
          return getListWidget(value: student[index]);
        }, itemCount: student.length,):
            ListView.builder(itemBuilder: (context, index) {
              return getListWidget(value: student[index]);
            },)

        // child: SingleChildScrollView(
        //   child: Column(
        //     children: [
        //       // Center(child: Text(student[0],style: TextStyle(color: Colors.black,fontSize: 50),)),
        //       // Center(child: Text(student[1],style: TextStyle(color: Colors.black,fontSize: 50),)),
        //       // Center(child: Text(student[2],style: TextStyle(color: Colors.black,fontSize: 50),)),
        //       // Center(child: Text(student[3],style: TextStyle(color: Colors.black,fontSize: 50),))
        //
        //       ...student.map((e)=> getListWidget(value: e)),
        //     ],
        //   ),
        //
        // ),
      ),
    );

  }

  Widget getListWidget({required value}){
    return Card(
        elevation: 10,
        color: Colors.blueGrey,
        child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  )
              ),
            ))
    );
  }
}
