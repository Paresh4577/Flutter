import 'dart:io';

void main(){
  stdout.write("Enter Number:");
  int num = int.parse(stdin.readLineSync()!);

  bool flag = true;

  for(int i=2;i<num;i++){
    if(num%i==0){
      flag = false;
    }
  }
  if(flag){
    stdout.writeln("The no is prime:");
  }
  else{
    stdout.writeln("The no is not prime:");
  }


}