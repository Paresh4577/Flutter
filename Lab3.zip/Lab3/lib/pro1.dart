import 'dart:io';

void main(){
  stdout.write("Enter Starting Range:");
  int start = int.parse(stdin.readLineSync()!);
  stdout.write("Enter Ending Range:");
  int end = int.parse(stdin.readLineSync()!);

  for(int i=start;i<=end;i++){
    if(i%2==0 && i%3!=0){
      stdout.writeln(i);
    }
  }

}