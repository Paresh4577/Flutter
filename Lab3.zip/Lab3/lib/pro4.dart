import 'dart:io';

void main(){
  stdout.write("Enter Number:");
  int num = int.parse(stdin.readLineSync()!);

  int rev = 0;
  int digit=0;
  while(num!=0){
    digit=num %10;
    rev = rev*10 + digit;
    num = num~/10;
  }

stdout.writeln(rev);
}