import 'dart:io';

void main(){
  int i,oddsum=0,evensum=0;
   stdout.writeln("Enter size of array:");
   int size = int.parse(stdin.readLineSync()!);


  for(int i=1;i<=size;i++){
    if(size==0){
      return;
    }
    if(i%2==0){
      evensum = evensum+i;
    }
    else{
      oddsum= oddsum+i;
    }
  }

  stdout.writeln("The Sum of Even no is: $evensum");
  stdout.writeln("The Sum of Odd no is: $oddsum");


}