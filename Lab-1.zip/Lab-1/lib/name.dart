import 'dart:io';

void main(){
  String name = stdin.readLineSync()!;

  stdout.writeln(name);
}