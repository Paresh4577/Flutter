import 'dart:io';

void main(){
  stdout.writeln("Enter The Feet:");
  int num = int.parse(stdin.readLineSync()!);

  stdout.writeln("Feet is: ${3.281*num}");
}