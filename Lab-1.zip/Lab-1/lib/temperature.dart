import 'dart:io';

void main(){
  stdout.writeln("Enter The Ferenhit:");
  int ferenhit = int.parse(stdin.readLineSync()!);


  stdout.writeln("celceuis: ${(ferenhit-32)*(5/9)}");
}