import 'dart:io';

void main(){
  stdout.writeln("Enter The First Number:");
  int num1 = int.parse(stdin.readLineSync()!);
  stdout.writeln("Enter The Second Number:");
  int num2 = int.parse(stdin.readLineSync()!);

  stdout.writeln("The Sum of Two Numbers is: ${num1+num2}");
}