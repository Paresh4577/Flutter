import 'dart:io';

void main(){
  stdout.writeln("Enter weight in pounds:");
  int pound = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter height in meters:");
  int inch = int.parse(stdin.readLineSync()!);
  
  
  double kg = pound/2.205;
  double meter = inch/39.37;

  stdout.writeln("The BMI is: ${kg/(meter*meter)}");


}