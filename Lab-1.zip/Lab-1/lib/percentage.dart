import 'dart:io';

void main(){
  stdout.writeln("Enter Marks of First Subject:");
  int sub1 = int.parse(stdin.readLineSync()!);
  stdout.writeln("Enter Marks of Second Subject:");
  int sub2 = int.parse(stdin.readLineSync()!);
  stdout.writeln("Enter Marks of Third Subject:");
  int sub3 = int.parse(stdin.readLineSync()!);
  stdout.writeln("Enter Marks of Fourth Subject:");
  int sub4 = int.parse(stdin.readLineSync()!);
  stdout.writeln("Enter Marks of Fifth Subject:");
  int sub5 = int.parse(stdin.readLineSync()!);

  double percentage = (sub1+sub2+sub3+sub4+sub5)/5;

  stdout.writeln("The Percentage of 5 Subjects Are: $percentage");


}