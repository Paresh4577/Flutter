
import 'package:flutter/material.dart';

class PageviewScreen extends StatefulWidget {
   PageviewScreen({super.key});

  @override
  State<PageviewScreen> createState() => _PageviewScreenState();
}

class _PageviewScreenState extends State<PageviewScreen> {
   PageController _controller = PageController();

  int selectedPageIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Center(child: Text('Page View Screen',style: TextStyle(color: Colors.white,),)),backgroundColor: Colors.black,),
      body: Column(
        children: [

          Expanded(
            child: PageView(
              controller: _controller,
              scrollDirection: Axis.horizontal,
              physics: BouncingScrollPhysics(),
              onPageChanged: (value) {
                selectedPageIndex=value;
                setState(() {

                });
              },
              children: [
                Container(
                  color: Colors.blue,
                  child: Center(child: Text("Page 1",style: TextStyle(color: Colors.white,fontSize: 30),)),
                ),
                Container(
                  color: Colors.red,
                  child: Center(child: Text("Page 2",style: TextStyle(color: Colors.white,fontSize: 30),)),
                ),
                Container(
                  color: Colors.green,
                  child: Center(child: Text("Page 3",style: TextStyle(color: Colors.white,fontSize: 30),)),
                ),
                Container(
                  color: Colors.purple,
                  child: Center(child: Text("Page 4",style: TextStyle(color: Colors.white,fontSize: 30),)),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ElevatedButton(onPressed: () {
                selectedPageIndex -= 1;
                setState(() {
                  _controller.jumpToPage(selectedPageIndex);
                });

              }, child: Icon(Icons.navigate_before,size: 50,color: Colors.blue,),),
              ElevatedButton(onPressed: () {
                selectedPageIndex += 1;
                setState(() {
                  _controller.jumpToPage(selectedPageIndex);
                });

              }, child: Icon(Icons.navigate_next,size: 50,color: Colors.blue,),),


            ],
          ),
        ],
      ),
    );
  }
}
