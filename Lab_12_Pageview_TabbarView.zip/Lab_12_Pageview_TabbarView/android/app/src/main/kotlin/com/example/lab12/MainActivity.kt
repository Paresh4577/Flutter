package com.example.lab12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
