import 'package:flutter/material.dart';
import 'package:lab13_userlist/UserAdd.dart';

class Homelist extends StatefulWidget {
  Map<String, dynamic>? userDetail = {};
  Homelist({super.key,this.userDetail});

  @override
  State<Homelist> createState() => _HomelistState();
}
class _HomelistState extends State<Homelist> {
  List<Map<String,dynamic>> userList = [
    {'UserName':'Paresh','City':'Rajkot'},
    {'UserName':'Raj','City':'Rajkot'},
    {'UserName':'Devendra','City':'Bhavnagar'},
    {'UserName':'Mohit','City':'Lalpur'},
    {'UserName':'Jay','City':'Jamanagar'},
    {'UserName':'Rohit','City':'Rajkot'},
  ];

  List<Map<String, dynamic>> search_list = [];
  // TextEditingController searchController = TextEditingController();

  void initState() {
    super.initState();
    search_list.addAll(userList);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("User List",style: TextStyle(fontSize: 30,color: Colors.white),),backgroundColor: Colors.black,
      actions: [
        InkWell(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                  children: [
                    Icon(Icons.add,color: Colors.white,size: 35,),
                    Text("Add User",style: TextStyle(fontSize: 25,color: Colors.white,),),
                    SizedBox(width: 10,)
                  ],
              )

            ],
          ),
          onTap: (){
           Navigator.of(context).push(
             MaterialPageRoute(builder: (context){
               return Useradd();
             }),
           ).then(
             (value) {
               setState(() {
                 return userList.add(value);
               });
             },
           );
          },



        )
      ],
      ),
      body: userList.length==0?
      Center(
        child: Text("No Users Found",style: TextStyle(fontSize: 30),),
      ):
      Column(
        children: [
          TextFormField(
            onChanged: (value) {
              userList.clear();
              for(int i=0;i<userList.length; i++){
                if(userList[i]['Username'].toString().toLowerCase().contains(value.toLowerCase())){
                  userList.add(userList[i]);
                }
              }
              setState(() {});
            },
          ),
          Expanded(
            child: ListView.builder(itemCount: userList.length,itemBuilder: (context, index) {
              return Card(
                child: Padding(padding: EdgeInsets.all(10),
                  child: Row(
                    children: [
                      // TextFormField(
                      //   onChanged: (value) {
                      //     print('Value:$value');
                      //   },
                      // ),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(userList[index]['UserName'],
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold
                                ),
                              ),
                              IconButton(onPressed: () {
                                 Navigator.push(context, MaterialPageRoute(builder: (context) {
                                   return Useradd(userDetail: userList[index],);
                                 })).then((value){
                                   setState(() {
                                     userList[index] = value;
                                   });
                                 });
                              }, icon: Icon(Icons.edit,color: Colors.orange,)),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(userList[index]['City'],
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 12,
                                  fontWeight: FontWeight.normal,
                                ),
                              ),
                              IconButton(onPressed: () {
                                showDialog(context: context, builder: (BuildContext context) {
                                  return AlertDialog(
                                    title: Text("User Delete"),
                                    content: SingleChildScrollView(
                                      child: ListBody(
                                        children: [
                                          Text("Are You Sure You Want to Delete?")
                                        ],
                                      ),
                                    ),
                                    actions: [
                                      TextButton(onPressed: () {
                                        userList.removeAt(index);
                                        setState(() { });
                                        Navigator.of(context).pop();
                                      }, child: Text("Ok")),
                                      TextButton(onPressed: () {
                                        Navigator.of(context).pop();
                                      }, child: Text("Cancel"))
                                    ],
                                  );
                                },);
                              }, icon: Icon(Icons.delete,color: Colors.red,)),
                            ],
                          ),
                        ],
                      ),
                      )
                    ],

                  ),
                ),
              );
            },),
          )
        ],

      ),


    );
  }
}
