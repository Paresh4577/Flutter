import 'package:flutter/material.dart';
import 'package:lab13_userlist/UserAdd.dart';

class Homelist extends StatefulWidget {
  const Homelist({super.key});

  @override
  State<Homelist> createState() => _HomelistState();
}

class _HomelistState extends State<Homelist> {
  List<Map<String,dynamic>> userList = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Center(child: Text("User List",style: TextStyle(fontSize: 30,color: Colors.white),),
      ),backgroundColor: Colors.black,
      actions: [
        InkWell(
          onTap: (){
           Navigator.of(context).push(
             MaterialPageRoute(builder: (context){
               return Useradd();
             }),
           ).then(
             (value) {
               setState(() {
                 return userList.add(value);
               });
             },
           );
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.add,color: Colors.white,),
              Text("Add User",style: TextStyle(fontSize: 15,color: Colors.white),)
            ],
          ),


        )
      ],
      ),
    );
  }
}
