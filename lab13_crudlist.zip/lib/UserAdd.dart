import 'package:flutter/material.dart';

class Useradd extends StatefulWidget {
  const Useradd({super.key});

  @override
  State<Useradd> createState() => _UseraddState();
}

class _UseraddState extends State<Useradd> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("UserAdd"),
    );
  }
}
