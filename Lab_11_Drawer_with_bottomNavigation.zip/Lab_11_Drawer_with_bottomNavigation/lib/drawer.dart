import 'package:flutter/material.dart';

class Bottom_Drawer extends StatefulWidget {
  const Bottom_Drawer({super.key});

  @override
  State<Bottom_Drawer> createState() => _Bottom_DrawerState();
}

class _Bottom_DrawerState extends State<Bottom_Drawer> {
  String value = "Home";
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text("BottomNavbar and Drawer"),),
      body: Center(
        child: Text(
            value,style: TextStyle(fontSize: 40),
        ),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            UserAccountsDrawerHeader(accountName: Text("Paresh Mori",style: TextStyle(fontSize: 20),), accountEmail: Text("paresh@gmail.com",style: TextStyle(fontSize: 20),),),
            ListTile(
              onTap: () {
                setState(() {
                  value = "Home";
                  Navigator.of(context).pop();
                });
              },
              leading: Icon(Icons.home),
              title: Text("Home"),
            ),
            Divider(height: 1,),
            ListTile(
              onTap: () {
                setState(() {
                  value = "Cart";
                  Navigator.of(context).pop();
                });
              },
              leading: Icon(Icons.shopping_cart),
              title: Text("Cart",),
            ),
            Divider(height: 1,),
            ListTile(
              onTap: () {
                setState(() {
                  value = "Check Out";
                  Navigator.of(context).pop();
                });
              },
              leading: Icon(Icons.shopping_cart_checkout_sharp),
              title: Text("Check Out"),
            ),
            Divider(height: 1,),
            Spacer(),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text("Log out"),
            ),
            Text("V.2.0"),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(
                icon: Icon(Icons.home),label: 'Home'),
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart),label: 'Cart'),
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart_checkout_sharp),label: 'Check Out'),
       ],

      ),
    );
  }
}
