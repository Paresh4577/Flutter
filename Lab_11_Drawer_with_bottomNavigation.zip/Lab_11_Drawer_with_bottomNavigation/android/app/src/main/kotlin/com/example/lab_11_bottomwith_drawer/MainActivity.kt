package com.example.lab_11_bottomwith_drawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
