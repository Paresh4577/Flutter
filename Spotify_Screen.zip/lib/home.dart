// import 'package:flutter/material.dart';
//
// class Home extends StatefulWidget {
//   @override
//   _HomeState createState() => _HomeState();
// }
//
// class _HomeState extends State<Home> {
//   int _currentIndex = 0;
//
//   final List<Widget> _tabs = [
//     HomeScreen(),
//     Notification(),
//     Order(),
//     Shopping(),
//     User(),
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: _tabs[_currentIndex],
//       bottomNavigationBar: BottomNavigationBar(
//         showUnselectedLabels: true,
//         fixedColor: Colors.black,
//         currentIndex: _currentIndex,
//         onTap: (int index) {
//           setState(() {
//             _currentIndex = index;
//           });
//         },
//         items: [
//           BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home',backgroundColor: Colors.blue),
//           BottomNavigationBarItem(icon: Icon(Icons.play_arrow_outlined),label: 'Explore',backgroundColor: Colors.blue),
//           BottomNavigationBarItem(icon: Icon(Icons.library_music_outlined),label: 'Library',backgroundColor: Colors.blue),
//           BottomNavigationBarItem(icon: Icon(Icons.person),label: 'Profile',backgroundColor: Colors.blue),
//         ],
//       ),
//
//
//
//     );
//   }
// }
//
// class HomeScreen extends StatelessWidget{
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Container(
//           color: Colors.blueGrey,
//           margin: EdgeInsets.all(20),
//           child: Column(
//             children: [
//               Container(
//                 color: Colors.white,
//                 child: TextField(
//                   decoration: InputDecoration(
//                     prefixIcon: Icon(Icons.search_off_outlined),
//                     hintText: "Search Your Favourite Songs Here",
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class Notification extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Text("Notifications"),
//     );
//   }
// }
//
// class Order extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Text("Orders"),
//     );
//   }
// }
//
// class Shopping extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Text("Shopping Cart"),
//     );
//   }
// }
//
// class User extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Text("Profile"),
//     );
//   }
//
// }

import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;
  List<Map<String,dynamic>> userList = [
    {'UserName':'Paresh'},
    {'UserName':'Raj'},
    {'UserName':'Devendra'},
    {'UserName':'Mohit'},
    {'UserName':'Jay'},
    {'UserName':'Rohit'},
  ];
  
  final List<Widget> _tabs = [
    HomeScreen(),
    NotificationScreen(),
    OrderScreen(),
    ShoppingScreen(),
    UserScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    //   body: Row(
    //     children: [
    //    Card(
    //   child: Row(
    //   children: [
    //   Text(userList[1]['UserName'],
    //     style: TextStyle(
    //         color: Colors.black,
    //         fontSize: 20,
    //         fontWeight: FontWeight.bold
    //     ),
    //   ),
    //     Text(userList[2]['UserName'],
    //       style: TextStyle(
    //           color: Colors.black,
    //           fontSize: 20,
    //           fontWeight: FontWeight.bold
    //       ),
    //     ),
    //   ],
    // ),
    // ),
    //     ],
    //   ),
      body: Column(
        children: [
          _tabs[_currentIndex],
          Expanded(child: ListView.builder(itemCount: userList.length,itemBuilder: (context, index) {
            return Card(
              child: Row(
                children: [
                  Text(userList[index]['UserName'],
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                ],
              ),
            );
          },))
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        showUnselectedLabels: true,
        fixedColor: Colors.black,
        currentIndex: _currentIndex,
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
              backgroundColor: Colors.blue),
          BottomNavigationBarItem(
              icon: Icon(Icons.play_arrow_outlined),
              label: 'Explore',
              backgroundColor: Colors.blue),
          BottomNavigationBarItem(
              icon: Icon(Icons.library_music_outlined),
              label: 'Library',
              backgroundColor: Colors.blue),
          BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
              backgroundColor: Colors.blue),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blueGrey, // Set background color here
      child: Center(
        child: Container(
          color: Colors.blueGrey,
          margin: EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                color: Colors.blueGrey[40],
                child: TextField(
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(vertical: 15),
                    // Adjust vertical padding
                    prefixIcon: Icon(Icons.search, color: Colors.white),
                    // Icon color
                    hintText: "Search Your Favourite Songs Here",
                    hintStyle: TextStyle(color: Colors.white),
                    // Hint text style
                    border: InputBorder.none, // Remove the default underline
                  ),
                  style: TextStyle(color: Colors.white), // Text style
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NotificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blueGrey[50], // Set background color here
      child: Center(
        child: Text("Notifications"),
      ),
    );
  }
}

class OrderScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blueGrey, // Set background color here
      child: Center(
        child: Text(
          "Orders",
          style: TextStyle(fontSize: 30, color: Colors.white),
        ),
      ),
    );
  }
}

class ShoppingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blueGrey[50], // Set background color here
      child: Center(
        child: Text("Shopping Cart"),
      ),
    );
  }
}

class UserScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blueGrey[50], // Set background color here
      child: Center(
        child: Text("Profile"),
      ),
    );
  }
}
