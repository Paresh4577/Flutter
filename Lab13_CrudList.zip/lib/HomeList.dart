import 'package:flutter/material.dart';
import 'package:lab13_userlist/UserAdd.dart';

class Homelist extends StatefulWidget {
  const Homelist({super.key});

  @override
  State<Homelist> createState() => _HomelistState();
}

class _HomelistState extends State<Homelist> {
  List<Map<String,dynamic>> userList = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("User List",style: TextStyle(fontSize: 30,color: Colors.white),),backgroundColor: Colors.black,
      actions: [
        InkWell(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                  children: [
                    Icon(Icons.add,color: Colors.white,size: 35,),
                    Text("Add User",style: TextStyle(fontSize: 25,color: Colors.white,),),
                    SizedBox(width: 10,)
                  ],
              )

            ],
          ),
          onTap: (){
           Navigator.of(context).push(
             MaterialPageRoute(builder: (context){
               return Useradd();
             }),
           ).then(
             (value) {
               setState(() {
                 return userList.add(value);
               });
             },
           );
          },



        )
      ],
      ),
      body: userList.length==0?
      Center(
        child: Text("No Users Found",style: TextStyle(fontSize: 30),),
      ):ListView.builder(itemCount: userList.length,itemBuilder: (context, index) {
        return Card(
          child: Padding(padding: EdgeInsets.all(10),
           child: Row(
             children: [
               Expanded(child: Column(
                 crossAxisAlignment: CrossAxisAlignment.start,
                 children: [
                   Text(userList[index]['UserName'],
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                    ),
                   ),
                   Text(userList[index]['City'],
                     style: TextStyle(
                       color: Colors.black,
                       fontSize: 12,
                       fontWeight: FontWeight.normal,
                     )
                 ],
               ))
             ],
           ),
          ),
        );
      },)
    );
  }
}
