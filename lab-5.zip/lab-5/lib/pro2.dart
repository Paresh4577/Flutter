
import 'dart:io';
void main(){
  List l1 = [];
  List l2 = [];

  for(int i=0;i<5;i++){
    stdout.write("Enter Elements: ");
    l1.add(int.parse(stdin.readLineSync()!));
  }

  for(int i=0;i<5;i++){
    stdout.write("Enter Elements: ");
    l2.add(int.parse(stdin.readLineSync()!));
  }

  for(int i=0;i<5;i++){
    for(int j=0;j<5;j++){
      if(l1[i]==l2[j]){
        stdout.writeln("Common element of both list: ${l1[i]}");
      }
    }

  }
}