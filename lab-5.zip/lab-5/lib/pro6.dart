import 'dart:io';

void main(){

   List<int> l1 = [];
   int sum=0;

   for(int i=0;i<5;i++){
     stdout.write("Enter Elements: ");
     l1.add(int.parse(stdin.readLineSync()!));
   }

   for(int i=0;i<5;i++){
     if(l1[i]%3==0 || l1[i]%5==0)
       sum = sum + l1[i];
     }

   print("The sum is : ${sum}");
   }




