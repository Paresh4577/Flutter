import 'dart:io';
void main(){
  List l1 = ["Delhi","Mumbai","Bangalore","Hydrabad","Ahmedabad"];
  
  l1.setAll(4, ["Surat"]);

  stdout.writeln(l1);
}