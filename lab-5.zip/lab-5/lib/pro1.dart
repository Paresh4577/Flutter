
import 'dart:io';

void main(){
  List l1 = new List.filled(5, 0);
  for(int i=0;i<l1.length;i++){
    stdout.write("Enter Elements: ");
    l1[i]=int.parse(stdin.readLineSync()!);
  }
  for(int i=0;i<5;i++){
    stdout.writeln(l1[i]);
  }
}