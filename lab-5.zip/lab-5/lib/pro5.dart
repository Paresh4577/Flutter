import 'dart:io';
class Friend{
  String name;
  int age;
  int num;

  Friend(this.name,this.age,this.num);

}
void main(){

  Map<dynamic,dynamic> a = {
    "Devu" : Friend("Devu",23,56565665),
    "Rohu" : Friend("Rohu",78,36565665),
    "Mohu" : Friend("Mohu",485,57565665)
  };

  friendName(String name){
    return a[name];
  }
 String fri = "Jay";
  Friend? findfriend = friendName(fri);

  print(":::::::::::::::::::::");
 if(findfriend!=null){
   print("Name : ${findfriend.name}");
 }



}