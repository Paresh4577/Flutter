import 'dart:io';
void main(){

  Map<dynamic,dynamic> a = {};
  a["name"] = "Paresh";
  a['Email'] = "paresh@gmail.com";
  a['number'] = 7984646723;

  print("Value of Phonebook Dictionary::${a}");

}