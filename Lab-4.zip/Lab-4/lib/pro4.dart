import 'dart:io';

void main(){
  stdout.writeln("Enter Num:");
  int num = int.parse(stdin.readLineSync()!);


  checkPrime(num);
}

int checkPrime(int num){
  bool flag = true;
  for(int i=2;i<num;i++){
    if(num%i==0){
      flag = false;
    }
  }
  if(flag){
    stdout.write("The No is prime:");
  }
  else{
    stdout.write("The No is Not Prime:");
  }
  return 0;
}