import 'dart:io';

void main(){
  // stdout.writeln("Enter size of array:");
  // int size = int.parse(stdin.readLineSync()!);

  var List = [1,4,6,44,55,32,56,54,67];
  int ceven = 0;
  int codd = 0;

  for(int i=0;i<List.length;i++){
     if(List[i]%2==0){
       ceven++;
     }
     else if(List[i]%2!=0){
       codd++;
     }
  }

  stdout.writeln("The Count of Even no is: $ceven");
  stdout.writeln("The Count of Odd no is: $codd");


}

