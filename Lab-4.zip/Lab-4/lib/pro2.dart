import 'dart:io';

void main(){
  stdout.writeln("Enter Num1:");
  int num1 = int.parse(stdin.readLineSync()!);
  stdout.writeln("Enter Num2:");
  int num2 = int.parse(stdin.readLineSync()!);

  greater(num1, num2);
}

int greater(int num1,int num2){
  if(num1>num2){
    stdout.write("The Num1 is Greater:");
  }
  else{
    stdout.write("The Num2 is Greater:");
  }
  return 0;
}