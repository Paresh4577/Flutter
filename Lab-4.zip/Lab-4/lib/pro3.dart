import 'dart:io';

void main(){
  stdout.writeln("Enter Num:");
  int num = int.parse(stdin.readLineSync()!);


  fibonacci(num);
}

int fibonacci(int num){
  int a=0,b=1,c=0;
  stdout.write("$a ");
  stdout.write("$b ");
  for(int i=3;i<=num;i++){
    c=a+b;
    stdout.write("$c ");
    a=b;
    b=c;
  }
  return 0;
}