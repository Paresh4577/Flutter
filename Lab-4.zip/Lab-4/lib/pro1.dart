import 'dart:io';

void main(){
  stdout.writeln("Enter Price:");
  double p = double.parse(stdin.readLineSync()!);
  stdout.writeln("Enter Rate of interest:");
  double r = double.parse(stdin.readLineSync()!);
  stdout.writeln("Enter N:");
  int n = int.parse(stdin.readLineSync()!);

   double ans = calculateInterest(p, r, n);
   stdout.write("The Simple interest is: $ans");
}

double calculateInterest(double p,double r,int n){
  return p*r*n / 100;
}