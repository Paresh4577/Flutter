package com.example.lab_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
