import 'package:flutter/material.dart';

class Program4 extends StatelessWidget {
  const Program4({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Program 4"),
      ),
      body: Center(
        child: Row(
          children: [
            Expanded(child: Column(
              children: [
                Expanded(
                  flex : 2,
                    child: Container(
                  color: Colors.grey,
                )),
                Expanded(
                  flex :3,
                    child: Container(
                  color: Colors.brown,
                )),
                Expanded(
                  flex : 3,
                    child: Container(
                  color: Colors.red,
                ))
              ],
            )),
            Expanded(child: Column(
              children: [
                Expanded(
                  flex : 4,
                    child: Container(
                  color: Colors.orange,
                )),
                Expanded(
                  flex : 3,
                    child: Container(
                  color: Colors.green,
                )),
                Expanded(
                  flex: 2,
                    child: Container(
                  color: Colors.yellow,
                ))
              ],
            )),
            Expanded(child: Column(
              children: [
                Expanded(
                  flex : 1,
                    child: Container(
                  color: Colors.blue,
                )),
                Expanded(
                  flex : 3,
                    child: Container(
                  color: Colors.blueGrey,
                )),
                Expanded(
                  flex : 2,
                    child: Container(
                  color: Colors.purple,
                ))
              ],
            ))
          ],
        ),
      ),
    );
  }
}
