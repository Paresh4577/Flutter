
import 'package:flutter/material.dart';

class Difference_part extends StatelessWidget {
  const Difference_part({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Program 1"),
      ),
      body: Center(
        child: Column(
          children: [
            Expanded(child: Row(
              children: [
                Expanded(child: Container(
                  color: Colors.blueGrey,
                ))
              ],
            ),),
            Expanded(child: Row(
              children: [
                Expanded(child: Container(
                  color: Colors.red,
                ))
              ],
            )),
            Expanded(child: Row(
              children: [
                Expanded(child: Container(
                  color: Colors.yellow,
                ))
              ],
            ))
          ],
        ),
      ),
    );
  }
}
