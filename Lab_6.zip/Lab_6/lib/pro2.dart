
import 'package:flutter/material.dart';

class Difference_col extends StatelessWidget {
  const Difference_col({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Program 2"),
      ),
      body: Center(
        child: Row(
          children: [
            Expanded(child: Row(
              children: [
                Expanded(child: Container(
                  color: Colors.orange,
                ))
              ],
            ),),
            Expanded(child: Row(
              children: [
                Expanded(child: Container(
                  color: Colors.white,
                ))
              ],
            )),
            Expanded(child: Row(
              children: [
                Expanded(child: Container(
                  color: Colors.green,
                ))
              ],
            ))
          ],
        ),
      ),
    );
  }
}