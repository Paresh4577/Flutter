package com.example.lab6_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
