package com.example.demofirstapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
