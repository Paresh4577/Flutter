import 'dart:js_interop';

import 'package:flutter/material.dart';
import 'package:shared_pref/UserAdd.dart';
import 'package:shared_preferences/shared_preferences.dart';
class SharedPreferenceDemo extends StatefulWidget {
  const SharedPreferenceDemo({super.key});

  @override
  State<SharedPreferenceDemo> createState() => _SharedPreferenceDemoState();
}

class _SharedPreferenceDemoState extends State<SharedPreferenceDemo> {
  SharedPreferences? _preferences;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
         actions: [
           IconButton(onPressed: () {
             Navigator.of(context).push(MaterialPageRoute(builder: (context) {
               return Useradd();
             },)).then((value) async {
               if(value!=null){
                 await _preferences!.setString('UserName', value['UserName']);
                 await _preferences!.setString('City', value['City']);
               }
             },);
           }, icon: Icon(Icons.add))
         ],
       ),
      body: Column(
        children: [
          FutureBuilder(future: SharedPreferences.getInstance(),
              builder: (context, snapshot) {
                print('Builder Called');
                if(snapshot.hasData){
                  _preferences = snapshot.data;
                  return Center(
                    child: Column(
                      children: [
                        Text('Data has been Initialized : ${snapshot.data!.getString('UserName')}'),
                        Text('Data has been Initialized : ${snapshot.data!.getString('City')}')
                      ],
                    ),
                  );
                }
                else if(snapshot.hasError){
                  return Text('ERROR HAS OCCURED : ${snapshot.error.toString()}');
                }
                else{
                  return CircularProgressIndicator();
                }
              }
              ,)
        ],
      ),
      );
  }
}
