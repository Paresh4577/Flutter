import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class MyDatabase {
  Future<Database> initDatabase() async {
    return openDatabase(
      join(await getDatabasesPath(), 'my_db.db'),
      version: 1,
      onCreate: (db, version) {
        db.execute( 'CREATE TABLE Tbl_User(UserID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, City TEXT)');
      },
    );
  }
  
  Future<int> insertDataIntoUsrTbl(map) async {
    Database db = await initDatabase();
    return await (await initDatabase()).insert('TBL_USER', map);
  }

  Future<List<Map<String, Object?>>> getDataFromUser() async {
    Database db = await initDatabase();
    return await (await initDatabase()).rawQuery('SELECT * From TBL_USER');
  }

  Future<int> deleteFromUser(UserId) async {
    Database db = await initDatabase();
    return await (await initDatabase()).delete('TBL_USER',where: 'UserID = ?',whereArgs: [UserId]);
  }

}