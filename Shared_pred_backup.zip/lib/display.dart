import 'package:flutter/material.dart';
import 'package:shared_pref/HomeList.dart';
import 'package:shared_pref/MyDB/mydb.dart';

class DisplayDetails extends StatelessWidget {
  const DisplayDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.black,title: Center(child: Text('CRUD WITH DB',style: TextStyle(fontSize: 20,color: Colors.white),)),),
      body: FutureBuilder(future: MyDatabase().initDatabase(), builder: (context, snapshot) {
        if(snapshot.hasData){
          return Homelist();
        }
        else{
          return Text('Not Connected');
        }
      },),
    );
  }
}
