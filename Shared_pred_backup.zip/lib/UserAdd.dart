

import 'package:flutter/material.dart';
import 'package:shared_pref/MyDB/mydb.dart';

class Useradd extends StatefulWidget {
  Map<String, dynamic>? userDetail = {};
  Useradd({super.key,this.userDetail});

  @override
  State<Useradd> createState() => _UseraddState();
}

class _UseraddState extends State<Useradd> {
  GlobalKey<FormState> _formkey = GlobalKey();
  MyDatabase db = MyDatabase();
  TextEditingController _userNameController = TextEditingController();
  TextEditingController _cityController = TextEditingController();


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _userNameController.text = widget.userDetail != null ? widget.userDetail!['UserName']:'';
    _cityController.text = widget.userDetail != null ? widget.userDetail!['City']:'';
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(foregroundColor: Colors.white,title: Text("Add User Form",style: TextStyle(color: Colors.white,),),backgroundColor: Colors.black,),
      body: Padding(padding: EdgeInsets.all(8),
       child: Form(
         key: _formkey,
         child: Column(
           children: [
             TextFormField(
               controller: _userNameController,
               decoration: InputDecoration(
                   hintText: "Enter User Name",
                   labelText: "Enter User Name"
               ),
             ),
             SizedBox(height: 20,),
             TextFormField(
               controller: _cityController,
               decoration: InputDecoration(
                   hintText: "Enter City",
                   labelText: "Enter City"
               ),
             ),
             SizedBox(height: 20,),
             ElevatedButton(style: ButtonStyle(
               backgroundColor: WidgetStatePropertyAll(Colors.green),
             ),onPressed: () async {
               int primaryKey;
                  if(_formkey.currentState!.validate()){
                    Map<String,dynamic> map = Map();
                    if(widget.userDetail == null){
                      map['Name'] = _userNameController.text.toString();
                      map['City'] = _cityController.text.toString();
                      primaryKey = await db.insertDataIntoUsrTbl(map);
                    }
                    else{
                      map['Name'] = _userNameController.text.toString();
                      map['City'] = _cityController.text.toString();
                      primaryKey = await db.insertDataIntoUsrTbl(map);
                    }

                    Navigator.of(context).pop(map);
                  }
             }, child: Text("Add",style: TextStyle(fontSize: 20,color: Colors.white),))
           ],
         ),
       ),
      ),
    );
  }
}
