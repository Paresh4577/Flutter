import 'package:flutter/material.dart';

import 'Order.dart';
import 'Profile.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;

  final List<Widget> _tabs = [
    HomeScreen(),
    Order(),
    LikedSongsScreen(),
    Profile(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _tabs[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        showUnselectedLabels: true,
        fixedColor: Colors.black,
        currentIndex: _currentIndex,
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
              backgroundColor: Colors.blueGrey),

          BottomNavigationBarItem(
              icon: Icon(Icons.library_music_outlined),
              label: 'Library',
              backgroundColor: Colors.blueGrey),
          BottomNavigationBarItem(
              icon: Icon(Icons.favorite_outlined),
              label: 'Liked Songs',
              backgroundColor: Colors.blueGrey),
          BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
              backgroundColor: Colors.blueGrey),

        ],
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> categories = [
    {'name': 'Hip-Hop'},
    {'name': 'Traditional'},
    {'name': 'Classic'},
    {'name': 'Jazz'},
  ];

  List<Map<String, String>> quickPicks = [
    { 'image': 'assets/dandelions.jfif'},
    { 'image': 'assets/starboy.jfif'},
    {'image': 'assets/until.jfif'},
    { 'image': 'assets/afterHours.jfif'},
    { 'image': 'assets/teriHogaiyaan.jfif'},
  ];

  List<Map<String, String>> topArtists = [
    {'title': 'Selena Gomez', 'image': 'assets/selena_gomez.jfif'},
    {'title': 'The Weeknd', 'image': 'assets/the_weekend.jfif'},
    {'title': 'Dua Lipa', 'image': 'assets/dua_lipa.jfif'},
    {'title': 'Vishal Mishra', 'image': 'assets/vishal_mishra.jfif'},
    {'title': 'Arjit Singh', 'image': 'assets/arjit_singh.jfif'},
  ];

  List<Map<String, String>> topHits = [
    {
      'title': 'Love Me Like You Do',
      'artist': 'Ellie Goulding',
      'image': 'assets/song1.jfif'
    },
    {
      'title': 'Talking To The Moon',
      'artist': 'Bruno Mars',
      'image': 'assets/song2.jfif'
    },
    {
      'title': 'I Want It That Way',
      'artist': 'Backstreet Boys',
      'image': 'assets/song3.jfif'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey,
      body: SingleChildScrollView(
        child: Container(
          color: Colors.blueGrey,
          margin: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 20),
                color: Colors.black38,
                child: TextField(
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(vertical: 15),
                    prefixIcon: Icon(Icons.search, color: Colors.blue,size: 30,),
                    hintText: "Search Your Favourite Songs Here",
                    hintStyle: TextStyle(color: Colors.white24),
                    border: InputBorder.none,
                  ),
                  style: TextStyle(color: Colors.black),
                ),
              ),
              // Categories Row
              HorizontalCategoryList(categories: categories),
              SizedBox(height: 20),
              // Quick Picks Section
              Text(
                'QUICK PICKS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Container(
                height: 145,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: quickPicks.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              quickPicks[index]['image']!,
                              width: 140,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(height: 5),

                        ],
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 10),
              // Top Hits Section
              Text(
                'TOP HITS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              ListView.builder(
                physics: NeverScrollableScrollPhysics(), // Disable scrolling in the list
                shrinkWrap: true, // Ensures it takes only necessary space
                itemCount: topHits.length,
                itemBuilder: (context, index) {
                  return Container(
                    margin: EdgeInsets.only(bottom: 10.0),
                    padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15.0),
                    decoration: BoxDecoration(
                      color: Colors.black38, // Different background color
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: InkWell(
                      onTap: () {
                        // Navigate to the MusicPlayerScreen
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MusicPlayerScreen(
                              image: topHits[index]['image']!,
                              title: topHits[index]['title']!,
                              artist: topHits[index]['artist']!,
                            ),
                          ),
                        );
                      },
                      child: ListTile(
                        contentPadding: EdgeInsets.zero, // Remove inner padding
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: Image.asset(
                            topHits[index]['image']!,
                            width: 50,
                            height: 45,
                            fit: BoxFit.cover,
                          ),
                        ),
                        title: Text(
                          topHits[index]['title']!,
                          style: TextStyle(color: Colors.white),
                          overflow: TextOverflow.ellipsis, // Ellipsis for long text
                        ),
                        subtitle: Text(
                          topHits[index]['artist']!,
                          style: TextStyle(color: Colors.white70),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min, // Ensures row takes only necessary space
                          children: [
                            Icon(Icons.favorite_border, color: Colors.white),
                            SizedBox(width: 10),
                            Icon(Icons.more_vert, color: Colors.white),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
              SizedBox(height: 15),
              Text(
                'TOP ARTISTS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Container(
                height: 155,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: quickPicks.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              topArtists[index]['image']!,
                              width: 120,
                              height: 100,
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            topArtists[index]['title']!,
                            style: TextStyle(color: Colors.white),
                            overflow: TextOverflow.ellipsis, // Ellipsis for long text
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// class NotificationScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.blueGrey.shade900,
//       appBar: AppBar(
//         backgroundColor: Colors.blueGrey.shade900,
//         title: Text('Profile',style: TextStyle(color: Colors.white),),
//         centerTitle: true,
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(20.0),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               CircleAvatar(
//                 radius: 50,
//                 backgroundImage: AssetImage('assets/me.jpeg'), // Provide your profile image here
//               ),
//               SizedBox(height: 20),
//               Text(
//                 'Paresh Mori',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 24,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               SizedBox(height: 5),
//               Text(
//                 'pareshmor58@gmail.com',
//                 style: TextStyle(
//                   color: Colors.white70,
//                   fontSize: 16,
//                 ),
//               ),
//               SizedBox(height: 30),
//               ProfileMenuItem(
//                 icon: Icons.favorite,
//                 title: 'Liked Songs',
//                 onTap: () {
//                   // Navigate to the Liked Songs screen
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => LikedSongsScreen(),
//                     ),
//                   );
//                 },
//               ),
//
//               ProfileMenuItem(
//                 icon: Icons.playlist_play,
//                 title: 'Saved Playlists',
//                 onTap: () {
//                   // Add your action here
//                 },
//               ),
//               ProfileMenuItem(
//                 icon: Icons.person,
//                 title: 'Account',
//                 onTap: () {
//                   // Add your action here
//                 },
//               ),
//               ProfileMenuItem(
//                 icon: Icons.notifications,
//                 title: 'Notifications',
//                 onTap: () {
//                   // Add your action here
//                 },
//               ),
//               ProfileMenuItem(
//                 icon: Icons.settings,
//                 title: 'Settings',
//                 onTap: () {
//                   // Add your action here
//                 },
//               ),
//               ProfileMenuItem(
//                 icon: Icons.logout,
//                 title: 'Log Out',
//                 onTap: () {
//                   // Add your action here
//                 },
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class LikedSongsScreen extends StatelessWidget {
//   final List<Map<String, String>> likedSongs = [
//     {'title': 'Starboy', 'artist': 'The Weeknd'},
//     {'title': 'Dandelions', 'artist': 'Ruth B'},
//     {'title': 'Satranga', 'artist': 'KK'},
//     {'title': 'Safar', 'artist': 'Jasleen Royal'},
//     // Add more songs if needed
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.blueGrey.shade800,
//         title: Text('Liked Songs',style: TextStyle(color:Colors.white),),
//       ),
//       backgroundColor: Colors.blueGrey.shade900,
//       body: ListView.builder(
//         itemCount: likedSongs.length,
//         itemBuilder: (context, index) {
//           return ListTile(
//             leading: Icon(Icons.music_note, color: Colors.white),
//             title: Text(
//               likedSongs[index]['title']!,
//               style: TextStyle(color: Colors.white),
//             ),
//             subtitle: Text(
//               likedSongs[index]['artist']!,
//               style: TextStyle(color: Colors.white70),
//             ),
//             trailing: Icon(Icons.favorite_outlined, color: Colors.white),
//             onTap: () {
//               // Handle song tap, for example, navigate to a music player screen
//               // or display a snackbar with the song name
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(
//                   content: Text('Playing ${likedSongs[index]['title']}'),
//                 ),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }
//
//
// class ProfileMenuItem extends StatelessWidget {
//   final IconData icon;
//   final String title;
//   final VoidCallback onTap;
//
//   ProfileMenuItem({required this.icon, required this.title, required this.onTap});
//
//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         margin: EdgeInsets.symmetric(vertical: 10),
//         padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
//         decoration: BoxDecoration(
//           color: Colors.blueGrey.shade800,
//           borderRadius: BorderRadius.circular(10),
//         ),
//         child: Row(
//           children: [
//             Icon(icon, color: Colors.white),
//             SizedBox(width: 20),
//             Text(
//               title,
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: 18,
//               ),
//             ),
//             Spacer(),
//             Icon(Icons.arrow_forward_ios, color: Colors.white),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class Order extends StatefulWidget {
//   @override
//   State<Order> createState() => _OrderState();
// }
//
// class _OrderState extends State<Order> {
//   final List<Map<String, dynamic>> categories = [
//     {'name': 'Traditional'},
//     {'name': 'Classic'},
//     {'name': 'Hip-Hop'},
//   ];
//
//   final List<Map<String, String>> recents = [
//     {'image': 'assets/duskTillDown.jfif'},
//     {'image': 'assets/infinity.jfif'},
//     {'image': 'assets/safar.jfif'},
//     {'image': 'assets/weDontTalk.jfif'},
//   ];
//
//   final List<Map<String, String>> topHits = [
//     {
//       'title': 'Starboy',
//       'artist': 'The Weeknd',
//       'image': 'assets/starboy.jfif'
//     },
//     {
//       'title': 'Satranga',
//       'artist': 'Arjit Singh',
//       'image': 'assets/satranga.jfif'
//     },
//     {
//       'title': 'We Dont Talk Anymore',
//       'artist': 'Charlie Puth',
//       'image': 'assets/weDontTalk.jfif'
//     },
//     {
//       'title': 'Where Are You',
//       'artist': 'Otnicka',
//       'image': 'assets/whereAreYou.jfif'
//     },
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.blueGrey,
//       appBar: AppBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         leading: CircleAvatar(
//           backgroundImage: AssetImage('assets/me.jpeg'), // Replace with your image
//         ),
//         title: Text("YOUR LIBRARY",style: TextStyle(color: Colors.white),),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.search,color: Colors.blue,),
//             onPressed: () {
//               // Implement search functionality
//             },
//           ),
//           IconButton(
//             icon: Icon(Icons.more_vert,color: Colors.white,),
//             onPressed: () {
//               // Implement more options functionality
//             },
//           ),
//         ],
//       ),
//       body: SingleChildScrollView(
//         child: Container(
//           color: Colors.blueGrey,
//           margin: EdgeInsets.all(30),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               // Categories Row
//               HorizontalCategoryList(categories: categories),
//               SizedBox(height: 20),
//
//               // Recents Section
//               Text(
//                 'RECENTS',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 20,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               SizedBox(height: 10),
//               Container(
//                 height: 150,
//                 child: ListView.builder(
//                   scrollDirection: Axis.horizontal,
//                   itemCount: recents.length,
//                   itemBuilder: (context, index) {
//                     return Padding(
//                       padding: const EdgeInsets.only(right: 8.0),
//                       child: ClipRRect(
//                         borderRadius: BorderRadius.circular(10),
//                         child: Image.asset(
//                           recents[index]['image']!,
//                           width: 150,
//                           height: 140,
//                           fit: BoxFit.cover,
//                         ),
//                       ),
//                     );
//                   },
//                 ),
//               ),
//               SizedBox(height: 20),
//
//               // Top Hits Section (Like the previous code)
//               ListView.builder(
//                 physics: NeverScrollableScrollPhysics(), // Disable scrolling in the list
//                 shrinkWrap: true, // Ensures it takes only necessary space
//                 itemCount: topHits.length, // Assuming you have a similar list for library top hits
//                 itemBuilder: (context, index) {
//                   return Container(
//                     margin: EdgeInsets.only(bottom: 10.0),
//                     padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15.0),
//                     decoration: BoxDecoration(
//                       color: Colors.black38, // Different background color
//                       borderRadius: BorderRadius.circular(10),
//                     ),
//                     child: InkWell(
//                       onTap: () {
//                         // Navigate to the MusicPlayerScreen
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                             builder: (context) => MusicPlayerScreen(
//                               image: topHits[index]['image']!,
//                               title: topHits[index]['title']!,
//                               artist: topHits[index]['artist']!,
//                             ),
//                           ),
//                         );
//                       },
//                       child: ListTile(
//                         contentPadding: EdgeInsets.zero, // Remove inner padding
//                         leading: ClipRRect(
//                           borderRadius: BorderRadius.circular(5),
//                           child: Image.asset(
//                             topHits[index]['image']!,
//                             width: 50,
//                             height: 45,
//                             fit: BoxFit.cover,
//                           ),
//                         ),
//                         title: Text(
//                           topHits[index]['title']!,
//                           style: TextStyle(color: Colors.white),
//                           overflow: TextOverflow.ellipsis, // Ellipsis for long text
//                         ),
//                         subtitle: Text(
//                           topHits[index]['artist']!,
//                           style: TextStyle(color: Colors.white70),
//                         ),
//                         trailing: Row(
//                           mainAxisSize: MainAxisSize.min, // Ensures row takes only necessary space
//                           children: [
//                             Icon(Icons.favorite_border, color: Colors.white),
//                             SizedBox(width: 10),
//                             Icon(Icons.more_vert, color: Colors.white),
//                           ],
//                         ),
//                       ),
//                     ),
//                   );
//                 },
//               ),
//
//
//               // ListView.builder(
//               //   physics: NeverScrollableScrollPhysics(), // Disable scrolling in the list
//               //   shrinkWrap: true, // Ensures it takes only necessary space
//               //   itemCount: topHits.length,
//               //   itemBuilder: (context, index) {
//               //     return Container(
//               //       margin: EdgeInsets.only(bottom: 10.0),
//               //       padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15.0),
//               //       decoration: BoxDecoration(
//               //         color: Colors.black38, // Different background color
//               //         borderRadius: BorderRadius.circular(10),
//               //       ),
//               //       child: ListTile(
//               //         contentPadding: EdgeInsets.zero, // Remove inner padding
//               //         leading: ClipRRect(
//               //           borderRadius: BorderRadius.circular(5),
//               //           child: Image.asset(
//               //             topHits[index]['image']!,
//               //             width: 50,
//               //             height: 45,
//               //             fit: BoxFit.cover,
//               //           ),
//               //         ),
//               //         title: Text(
//               //           topHits[index]['title']!,
//               //           style: TextStyle(color: Colors.white),
//               //           overflow: TextOverflow.ellipsis, // Ellipsis for long text
//               //         ),
//               //         subtitle: Text(
//               //           topHits[index]['artist']!,
//               //           style: TextStyle(color: Colors.white70),
//               //         ),
//               //         trailing: Row(
//               //           mainAxisSize: MainAxisSize.min, // Shrinks the row to its content size
//               //           children: [
//               //             SizedBox(width: 5),
//               //             Text(
//               //               "...",
//               //               style: TextStyle(color: Colors.white,fontSize: 30),
//               //             ),
//               //           ],
//               //         ),
//               //       ),
//               //     );
//               //   },
//               // ),
//             ],
//           ),
//         ),
//       ),
//
//     );
//   }
// }

// Horizontal Category List
class HorizontalCategoryList extends StatelessWidget {
  final List<Map<String, dynamic>> categories;

  HorizontalCategoryList({required this.categories});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      margin: EdgeInsets.all(10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        itemBuilder: (context, index) {
          return Container(
            margin: EdgeInsets.symmetric(horizontal: 10),
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.black38,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(
                categories[index]['name'],
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}



class MusicPlayerScreen extends StatelessWidget {
  final String image;
  final String title;
  final String artist;

  MusicPlayerScreen({
    required this.image,
    required this.title,
    required this.artist,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.keyboard_arrow_down,color: Colors.white,),
          onPressed: () {
            Navigator.pop(context); // Go back to the previous screen
          },
        ),
        title: Text(
          title,
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.more_vert,color: Colors.white,),
            onPressed: () {
              // Handle more options
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Album Cover
            ClipRRect(
              borderRadius: BorderRadius.circular(15.0),
              child: Image.asset(
                image,
                height: 400,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 20),

            // Song Title
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 10),

            // Artist Name
            Text(
              artist,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 18,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),

            // Slider for Song Progress
            Slider(
              value: 0.3, // Example value
              onChanged: (value) {
                // Handle slider value change
              },
              activeColor: Colors.white,
              inactiveColor: Colors.white54,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "0:30",
                  style: TextStyle(color: Colors.white70),
                ),
                Text(
                  "-2:30",
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
            SizedBox(height: 20),

            // Playback Controls
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(Icons.shuffle),
                  color: Colors.white,
                  iconSize: 30,
                  onPressed: () {
                    // Handle shuffle
                  },
                ),
                SizedBox(width: 20),
                IconButton(
                  icon: Icon(Icons.skip_previous),
                  color: Colors.white,
                  iconSize: 40,
                  onPressed: () {
                    // Handle previous track
                  },
                ),
                SizedBox(width: 20),
                CircleAvatar(
                  radius: 35,
                  backgroundColor: Colors.white,
                  child: IconButton(
                    icon: Icon(Icons.play_arrow),
                    color: Colors.blueGrey,
                    iconSize: 50,
                    onPressed: () {
                      // Handle play/pause
                    },
                  ),
                ),
                SizedBox(width: 20),
                IconButton(
                  icon: Icon(Icons.skip_next),
                  color: Colors.white,
                  iconSize: 40,
                  onPressed: () {
                    // Handle next track
                  },
                ),
                SizedBox(width: 20),
                IconButton(
                  icon: Icon(Icons.repeat),
                  color: Colors.white,
                  iconSize: 30,
                  onPressed: () {
                    // Handle repeat
                  },
                ),
              ],
            ),
            SizedBox(height: 20),

            // Swipe Up for Lyrics
            Text(
              "Swipe up for lyrics",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}




















// import 'package:flutter/material.dart';
//
// class Home extends StatefulWidget {
//   @override
//   _HomeState createState() => _HomeState();
// }
//
// class _HomeState extends State<Home> {
//   int _currentIndex = 0;
//   List<Map<String, dynamic>> userList = [
//     {'UserName': 'Paresh'},
//     {'UserName': 'Raj'},
//     {'UserName': 'Devendra'},
//     {'UserName': 'Mohit'},
//     {'UserName': 'Jay'},
//     {'UserName': 'Rohit'},
//   ];
//
//   final List<Widget> _tabs = [
//     NotificationScreen(),
//     OrderScreen(),
//     ShoppingScreen(),
//     UserScreen(),
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Row(
//         children: [
//           Card(
//             child: Row(
//               children: [
//                 Text(
//                   userList[1]['UserName'],
//                   style: TextStyle(
//                       color: Colors.black,
//                       fontSize: 20,
//                       fontWeight: FontWeight.bold),
//                 ),
//                 Text(
//                   userList[2]['UserName'],
//                   style: TextStyle(
//                       color: Colors.black,
//                       fontSize: 20,
//                       fontWeight: FontWeight.bold),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//         body: Column(
//           children: [
//             _tabs[_currentIndex],
//             Expanded(child: ListView.builder(itemCount: userList.length,itemBuilder: (context, index) {
//               return Card(
//                 child: Row(
//                   children: [
//                     Text(userList[index]['UserName'],
//                       style: TextStyle(
//                           color: Colors.black,
//                           fontSize: 20,
//                           fontWeight: FontWeight.bold
//                       ),
//                     ),
//                   ],
//                 ),
//               );
//             },))
//           ],
//         ),
//       bottomNavigationBar: BottomNavigationBar(
//         showUnselectedLabels: true,
//         fixedColor: Colors.black,
//         currentIndex: _currentIndex,
//         onTap: (int index) {
//           setState(() {
//             _currentIndex = index;
//           });
//         },
//         items: [
//           BottomNavigationBarItem(
//               icon: Icon(Icons.home),
//               label: 'Home',
//               backgroundColor: Colors.blue),
//           BottomNavigationBarItem(
//               icon: Icon(Icons.play_arrow_outlined),
//               label: 'Explore',
//               backgroundColor: Colors.blue),
//           BottomNavigationBarItem(
//               icon: Icon(Icons.library_music_outlined),
//               label: 'Library',
//               backgroundColor: Colors.blue),
//           BottomNavigationBarItem(
//               icon: Icon(Icons.person),
//               label: 'Profile',
//               backgroundColor: Colors.blue),
//         ],
//       ),
//     );
//   }
// }
//
// class HomeScreen extends StatefulWidget {
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.blueGrey, // Set background color here
//       child: Center(
//         child: Container(
//           color: Colors.blueGrey,
//           margin: EdgeInsets.all(20),
//           child: Column(
//             children: [
//               Container(
//                 color: Colors.blueGrey[40],
//                 child: TextField(
//                   decoration: InputDecoration(
//                     contentPadding: EdgeInsets.symmetric(vertical: 15),
//                     // Adjust vertical padding
//                     prefixIcon: Icon(Icons.search, color: Colors.white),
//                     // Icon color
//                     hintText: "Search Your Favourite Songs Here",
//                     hintStyle: TextStyle(color: Colors.white),
//                     // Hint text style
//                     border: InputBorder.none, // Remove the default underline
//                   ),
//                   style: TextStyle(color: Colors.white), // Text style
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class NotificationScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.blueGrey[50], // Set background color here
//       child: Center(
//         child: Text("Notifications"),
//       ),
//     );
//   }
// }
//
// class OrderScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.blueGrey, // Set background color here
//       child: Center(
//         child: Text(
//           "Orders",
//           style: TextStyle(fontSize: 30, color: Colors.white),
//         ),
//       ),
//     );
//   }
// }
//
// class ShoppingScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.blueGrey[50], // Set background color here
//       child: Center(
//         child: Text("Shopping Cart"),
//       ),
//     );
//   }
// }
//
// class UserScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.blueGrey[50], // Set background color here
//       child: Center(
//         child: Text("Profile"),
//       ),
//     );
//   }
// }
