import 'package:flutter/material.dart';

class LikedSongsScreen extends StatelessWidget {
  final List<Map<String, String>> likedSongs = [
    {'title': 'Starboy', 'artist': 'The Weeknd'},
    {'title': 'Dandelions', 'artist': 'Ruth B'},
    {'title': 'Satranga', 'artist': 'KK'},
    {'title': 'Safar', 'artist': 'Jasleen Royal'},
    // Add more songs if needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text('Liked Songs',style: TextStyle(color:Colors.white),),
      ),
      backgroundColor: Colors.blueGrey,
      body: ListView.builder(
        itemCount: likedSongs.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.music_note, color: Colors.white),
            title: Text(
              likedSongs[index]['title']!,
              style: TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              likedSongs[index]['artist']!,
              style: TextStyle(color: Colors.white70),
            ),
            trailing: Icon(Icons.favorite_outlined, color: Colors.white),
            onTap: () {
              // Handle song tap, for example, navigate to a music player screen
              // or display a snackbar with the song name
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Playing ${likedSongs[index]['title']}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
