import 'package:flutter/material.dart';

import 'home.dart';

class Order extends StatefulWidget {
  const Order({Key? key}) : super(key: key);

  @override
  State<Order> createState() => _OrderState();
}

class _OrderState extends State<Order> {
  final List<Map<String, dynamic>> categories = [
    {'name': 'Traditional'},
    {'name': 'Classic'},
    {'name': 'Hip-Hop'},
  ];

  final List<Map<String, String>> recents = [
    {'image': 'assets/duskTillDown.jfif'},
    {'image': 'assets/infinity.jfif'},
    {'image': 'assets/safar.jfif'},
    {'image': 'assets/weDontTalk.jfif'},
  ];

  final List<Map<String, String>> topHits = [
    {
      'title': 'Starboy',
      'artist': 'The Weeknd',
      'image': 'assets/starboy.jfif'
    },
    {
      'title': 'Satranga',
      'artist': 'Arjit Singh',
      'image': 'assets/satranga.jfif'
    },
    {
      'title': 'We Dont Talk Anymore',
      'artist': 'Charlie Puth',
      'image': 'assets/weDontTalk.jfif'
    },
    {
      'title': 'Where Are You',
      'artist': 'Otnicka',
      'image': 'assets/whereAreYou.jfif'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/me.jpeg'), // Replace with your image
        ),
        title: Text("YOUR LIBRARY",style: TextStyle(color: Colors.white),),
        actions: [
          IconButton(
            icon: Icon(Icons.search,color: Colors.blue,),
            onPressed: () {
              // Implement search functionality
            },
          ),
          IconButton(
            icon: Icon(Icons.more_vert,color: Colors.white,),
            onPressed: () {
              // Implement more options functionality
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.blueGrey,
          margin: EdgeInsets.all(30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Categories Row
              HorizontalCategoryList(categories: categories),
              SizedBox(height: 20),

              // Recents Section
              Text(
                'RECENTS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Container(
                height: 150,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: recents.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset(
                          recents[index]['image']!,
                          width: 150,
                          height: 140,
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 20),

              // Top Hits Section (Like the previous code)
              ListView.builder(
                physics: NeverScrollableScrollPhysics(), // Disable scrolling in the list
                shrinkWrap: true, // Ensures it takes only necessary space
                itemCount: topHits.length, // Assuming you have a similar list for library top hits
                itemBuilder: (context, index) {
                  return Container(
                    margin: EdgeInsets.only(bottom: 10.0),
                    padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15.0),
                    decoration: BoxDecoration(
                      color: Colors.black38, // Different background color
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: InkWell(
                      onTap: () {
                        // Navigate to the MusicPlayerScreen
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MusicPlayerScreen(
                              image: topHits[index]['image']!,
                              title: topHits[index]['title']!,
                              artist: topHits[index]['artist']!,
                            ),
                          ),
                        );
                      },
                      child: ListTile(
                        contentPadding: EdgeInsets.zero, // Remove inner padding
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: Image.asset(
                            topHits[index]['image']!,
                            width: 50,
                            height: 45,
                            fit: BoxFit.cover,
                          ),
                        ),
                        title: Text(
                          topHits[index]['title']!,
                          style: TextStyle(color: Colors.white),
                          overflow: TextOverflow.ellipsis, // Ellipsis for long text
                        ),
                        subtitle: Text(
                          topHits[index]['artist']!,
                          style: TextStyle(color: Colors.white70),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min, // Ensures row takes only necessary space
                          children: [
                            Icon(Icons.favorite_border, color: Colors.white),
                            SizedBox(width: 10),
                            Icon(Icons.more_vert, color: Colors.white),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),


              // ListView.builder(
              //   physics: NeverScrollableScrollPhysics(), // Disable scrolling in the list
              //   shrinkWrap: true, // Ensures it takes only necessary space
              //   itemCount: topHits.length,
              //   itemBuilder: (context, index) {
              //     return Container(
              //       margin: EdgeInsets.only(bottom: 10.0),
              //       padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15.0),
              //       decoration: BoxDecoration(
              //         color: Colors.black38, // Different background color
              //         borderRadius: BorderRadius.circular(10),
              //       ),
              //       child: ListTile(
              //         contentPadding: EdgeInsets.zero, // Remove inner padding
              //         leading: ClipRRect(
              //           borderRadius: BorderRadius.circular(5),
              //           child: Image.asset(
              //             topHits[index]['image']!,
              //             width: 50,
              //             height: 45,
              //             fit: BoxFit.cover,
              //           ),
              //         ),
              //         title: Text(
              //           topHits[index]['title']!,
              //           style: TextStyle(color: Colors.white),
              //           overflow: TextOverflow.ellipsis, // Ellipsis for long text
              //         ),
              //         subtitle: Text(
              //           topHits[index]['artist']!,
              //           style: TextStyle(color: Colors.white70),
              //         ),
              //         trailing: Row(
              //           mainAxisSize: MainAxisSize.min, // Shrinks the row to its content size
              //           children: [
              //             SizedBox(width: 5),
              //             Text(
              //               "...",
              //               style: TextStyle(color: Colors.white,fontSize: 30),
              //             ),
              //           ],
              //         ),
              //       ),
              //     );
              //   },
              // ),
            ],
          ),
        ),
      ),

    );
  }
}

