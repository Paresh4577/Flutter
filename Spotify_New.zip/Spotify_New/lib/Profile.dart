import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey.shade900,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey.shade900,
        title: Text('Profile',style: TextStyle(color: Colors.white),),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('assets/me.jpeg'), // Provide your profile image here
              ),
              SizedBox(height: 20),
              Text(
                'Paresh Mori',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'pareshmor58@gmail.com',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 30),
              ProfileMenuItem(
                icon: Icons.favorite,
                title: 'Liked Songs',
                onTap: () {
                  // Navigate to the Liked Songs screen
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => LikedSongsScreen(),
                    ),
                  );
                },
              ),

              ProfileMenuItem(
                icon: Icons.playlist_play,
                title: 'Saved Playlists',
                onTap: () {
                  // Add your action here
                },
              ),
              ProfileMenuItem(
                icon: Icons.person,
                title: 'Account',
                onTap: () {
                  // Add your action here
                },
              ),
              ProfileMenuItem(
                icon: Icons.notifications,
                title: 'Notifications',
                onTap: () {
                  // Add your action here
                },
              ),
              ProfileMenuItem(
                icon: Icons.settings,
                title: 'Settings',
                onTap: () {
                  // Add your action here
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LikedSongsScreen extends StatelessWidget {
  final List<Map<String, String>> likedSongs = [
    {'title': 'Starboy', 'artist': 'The Weeknd'},
    {'title': 'Dandelions', 'artist': 'Ruth B'},
    {'title': 'Satranga', 'artist': 'KK'},
    {'title': 'Safar', 'artist': 'Jasleen Royal'},
    // Add more songs if needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey.shade800,
        title: Text('Liked Songs',style: TextStyle(color:Colors.white),),
      ),
      backgroundColor: Colors.blueGrey.shade900,
      body: ListView.builder(
        itemCount: likedSongs.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.music_note, color: Colors.white),
            title: Text(
              likedSongs[index]['title']!,
              style: TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              likedSongs[index]['artist']!,
              style: TextStyle(color: Colors.white70),
            ),
            trailing: Icon(Icons.favorite_outlined, color: Colors.white),
            onTap: () {
              // Handle song tap, for example, navigate to a music player screen
              // or display a snackbar with the song name
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Playing ${likedSongs[index]['title']}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}


class ProfileMenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  ProfileMenuItem({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 10),
        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
        decoration: BoxDecoration(
          color: Colors.blueGrey.shade800,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white),
            SizedBox(width: 20),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
              ),
            ),
            Spacer(),
            Icon(Icons.arrow_forward_ios, color: Colors.white),
          ],
        ),
      ),
    );
  }
}