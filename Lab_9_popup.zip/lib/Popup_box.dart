import 'package:flutter/material.dart';

class ImgWithText2 extends StatelessWidget {
  const ImgWithText2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Image with Text 2"),
        actions: [
          PopupMenuButton(itemBuilder: (context)=>[
            PopupMenuItem(child: Row(
              children: [
                getIcons(icon: Icons.info, title: "About Us"),
                getIcons(icon: Icons.abc_rounded, title: "More Apps"),
                getIcons(icon: Icons.person, title: "Contact Us"),
              ],
            ))
          ])

        ],
      ),

      body: Column(
        children: [
          Expanded(
              child: Row(
                children: [
                  Expanded(
                      flex: 2,
                      child: Container(
                        child: Center(
                          child: Text("Image1"),
                        ),
                        color: Colors.blue,
                      )),
                  Expanded(child: Container()),
                  Image.asset(
                    'assets/img/tiger.jpg',
                    fit: BoxFit.fill,
                  )
                ],
              )),
          Expanded(
              flex: 1,
              child: Row(
                children: [
                  Expanded(child: Container(
                    child: Column(
                      children: [
                        Expanded(child: Container(
                          child: Center(
                            child: Text("Image2"),
                          ),
                          color: Colors.yellow,
                        )),
                        Expanded(child: Container(
                          child: Center(
                            child: Text("Image4"),
                          ),
                          color: Colors.purple,
                        ))
                      ],
                    ),
                  )),
                  Expanded(child: Container(
                    child: Column(
                      children: [
                        Expanded(child: Container(
                          color: Colors.black,
                        )),
                        Expanded(child: Container(
                          color: Colors.green,
                        ))
                      ],
                    ),
                  )),
                  Expanded(child: Container(
                    child: Column(
                      children: [
                        Expanded(child: Container(
                          child: Center(
                            child: Text("Image3",style: TextStyle(color: Colors.white)),
                          ),
                          color: Colors.orange,
                        )),
                        Expanded(child: Container(
                          child: Center(
                            child: Text("Image4"),
                          ),
                          color: Colors.red,
                        ))
                      ],
                    ),
                  ))
                ],
              )),
          Expanded(
              flex: 1,
              child: Row(

              )),
        ],
      ),
    );


  }
  Widget getIcons({required IconData icon,required String title}){
    return

      PopupMenuButton(itemBuilder: (context)=>[

      ];


  }
}
