import 'dart:ffi';
import 'dart:io';

void main(){
  stdout.writeln("Enter marks of 1 subject");
  int sub1 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter marks of 2 subject");
  int sub2 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter marks of 3 subject");
  int sub3 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter marks of 4 subject");
  int sub4 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter marks of 5 subject");
  int sub5 = int.parse(stdin.readLineSync()!);

  int total = sub1+sub2+sub3+sub4+sub5;
  double percentage = total/5;

  if(percentage<35){
    stdout.writeln("Fail!");
  }
  else if(percentage>35 && percentage<45){
    stdout.writeln("Pass");
  }
  else if(percentage>45 && percentage<60){
    stdout.writeln("Second class");
  }
  else if(percentage>60 && percentage<70){
    stdout.writeln("First class");
  }
  else if(percentage>=70){
    stdout.writeln("Distinction");
  }
  else{
    stdout.writeln("Invalid Input!");
  }




}