import 'dart:ffi';
import 'dart:io';

void main(){
  stdout.writeln("Enter 1 Number");
  int num1 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter 2 Number");
  int num2 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter 3 Number:");
  int num3 = int.parse(stdin.readLineSync()!);

  stdout.writeln((num1<num2)?(num3<num2)?num2:num3:num1);





}