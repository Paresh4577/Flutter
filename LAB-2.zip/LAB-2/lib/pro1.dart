import 'dart:io';

void main(){
  stdout.writeln("Enter Number to check if no is positive or nagative");
  int num = int.parse(stdin.readLineSync()!);

  if(num<0){
    stdout.writeln("The No is Nagative:");
  }
  else{
    stdout.writeln("The No is Positive:");
  }



}