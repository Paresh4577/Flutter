import 'dart:ffi';
import 'dart:io';

void main(){
  stdout.writeln("Enter 1 Number");
  int num1 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter 2 Number");
  int num2 = int.parse(stdin.readLineSync()!);

  stdout.writeln("Enter Your Choice:");
  String choice = stdin.readLineSync()!;


  switch(choice){
    case "+":
      stdout.writeln("The Addition is: ${num1+num2}");
      break;
    case "-":
      stdout.writeln("The Substraction is: ${num1-num2}");
      break;
    case "*":
      stdout.writeln("The Multiplication is: ${num1*num2}");
      break;
    case "/" :
      stdout.writeln("The Division is: ${num1/num2}");
      break;
  }

}