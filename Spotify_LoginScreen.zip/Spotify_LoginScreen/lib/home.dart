import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;

  final List<Widget> _tabs = [
    HomeScreen(),
    Notification(),
    Order(),
    Shopping(),
    User(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _tabs[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        showUnselectedLabels: true,
        fixedColor: Colors.black,
        currentIndex: _currentIndex,
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home',backgroundColor: Colors.blue),
          BottomNavigationBarItem(icon: Icon(Icons.play_arrow_outlined),label: 'Explore',backgroundColor: Colors.blue),
          BottomNavigationBarItem(icon: Icon(Icons.library_music_outlined),label: 'Library',backgroundColor: Colors.blue),
          BottomNavigationBarItem(icon: Icon(Icons.person),label: 'Profile',backgroundColor: Colors.blue),
        ],
      ),



    );
  }
}

class HomeScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          color: Colors.blueGrey,
          margin: EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                color: Colors.white,
                child: TextField(
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.search_off_outlined),
                    hintText: "Search Your Favourite Songs Here",
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Notification extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Notifications"),
    );
  }
}

class Order extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Orders"),
    );
  }
}

class Shopping extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Shopping Cart"),
    );
  }
}

class User extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Profile"),
    );
  }

}
