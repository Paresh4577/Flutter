
import 'package:flutter/material.dart';

class Listproject extends StatelessWidget {
   Listproject({super.key});

  List student = ["Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit","Paresh","Raj","Devendra","Mohit","Rohit"];


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Center(child: Text("List Scrolling Widgets",style: TextStyle(fontSize: 30),)),
        backgroundColor: Colors.blue,foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Center(child: Text(student[0],style: TextStyle(color: Colors.black,fontSize: 50),)),
            // Center(child: Text(student[1],style: TextStyle(color: Colors.black,fontSize: 50),)),
            // Center(child: Text(student[2],style: TextStyle(color: Colors.black,fontSize: 50),)),
            // Center(child: Text(student[3],style: TextStyle(color: Colors.black,fontSize: 50),))

            ...student.map((e)=> getListWidget(value: e)),
          ],
        ),

      ),
    );

  }

  Widget getListWidget({required value}){
    return
        ListTile(
          title: Center(child: Text(value,style: TextStyle(fontSize: 30,color: Colors.black,fontWeight: FontWeight.bold),)),
    );
  }
}
